package com.hofstracsc190.myapplication.hofswap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class CreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        //Getting all components


        final EditText emailEditText = (EditText) findViewById(R.id.emailEditText2);
        final EditText firstNameEditText = (EditText) findViewById(R.id.firstNameEditText);
        final EditText lastNameEditText = (EditText) findViewById(R.id.lastNameEditText);
        final EditText idNumEditText = (EditText) findViewById(R.id.idNumEditText);
        final EditText pass1EditText = (EditText) findViewById(R.id.pass1EditText);
        final EditText pass2EditText = (EditText) findViewById(R.id.pass2EditText);
        Button finishBtn = (Button) findViewById(R.id.finishButton);

        TextView errorTextView = (TextView) findViewById(R.id.errorTextView);




        finishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email;
                String firstName;
                String lastName;
                String idNum;
                String pass1;
                String pass2;

                email = emailEditText.getText().toString();
                firstName = firstNameEditText.getText().toString();
                lastName = lastNameEditText.getText().toString();
                idNum = idNumEditText.getText().toString();
                pass1 = pass1EditText.getText().toString();
                pass2 = pass2EditText.getText().toString();

            }
        });


    }
}
