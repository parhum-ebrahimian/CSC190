package com.hofstracsc190.myapplication.hofswap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText emailEditText = (EditText) findViewById(R.id.emailEditText);
        final EditText passwordEditText = (EditText) findViewById(R.id.passwordEditText);
        Button loginBtn = (Button) findViewById(R.id.loginButton);
        Button accountCreateBtn = (Button) findViewById(R.id.accountCreateBtn);
        TextView responseTextView = (TextView) findViewById(R.id.responseTextView);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();


            }
        });

        accountCreateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startAccountCreate =  new Intent(getApplicationContext(), UploadPage.class);
                startActivity(startAccountCreate);

            }
        });


    }
}
