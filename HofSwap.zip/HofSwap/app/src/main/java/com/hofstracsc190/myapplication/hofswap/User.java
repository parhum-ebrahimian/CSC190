package com.hofstracsc190.myapplication.hofswap;

public class User {
    public User(String idNum, String email, String firstName, String lastName)
    {

    }
}
