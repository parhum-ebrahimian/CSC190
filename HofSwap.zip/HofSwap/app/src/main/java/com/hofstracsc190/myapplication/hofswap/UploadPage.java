package com.hofstracsc190.myapplication.hofswap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class UploadPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_page);
        //Setting up spinner
        final Spinner conditionSpinner = (Spinner) findViewById(R.id.conditionSpinner);

        ArrayAdapter<String> conditionsAdapter = new ArrayAdapter<String>(UploadPage.this,
                android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.conditions));//container that will hold vales and integrate them with spinner
        conditionsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conditionSpinner.setAdapter(conditionsAdapter);

        //end spinner setup

        final EditText titleEditText = (EditText) findViewById(R.id.titleEditText);
        final EditText authorEditText = (EditText) findViewById(R.id.authorEditText);
        final EditText isbnEditText = (EditText) findViewById(R.id.isbnEditText);
        Button uploadButton = (Button) findViewById(R.id.uploadBtn);

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title;
                String author;
                String isbn;
                String condition;

                title = titleEditText.getText().toString();
                author = authorEditText.getText().toString();
                isbn = isbnEditText.getText().toString();
                condition = conditionSpinner.getSelectedItem().toString();
            }
        });
    }
}
